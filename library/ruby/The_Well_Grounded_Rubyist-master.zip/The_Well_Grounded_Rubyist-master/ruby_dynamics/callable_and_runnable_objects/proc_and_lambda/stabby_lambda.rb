puts



lam = -> x, y { p [x, y] }
lam.call(4, 5) #=> [4, 5]



puts