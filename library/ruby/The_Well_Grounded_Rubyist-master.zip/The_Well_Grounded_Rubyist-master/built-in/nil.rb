puts



a = ['1', '2', '3'][4]
p a    # nil

a = nil.to_s
p a

a = nil.to_i
p a

a = nil.object_id
p a



puts