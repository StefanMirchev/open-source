puts



p h = {}
p Hash.new

p Hash["Connecticut", "CT", "Delaware", "DE" ]
p Hash[ [[1,2], [3,4], [5,6]] ]



puts