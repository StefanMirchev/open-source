puts



p %w{ David A. Black }
p %w{ David\ A.\ Black is a Rubyist. }
p %W{ David is #{2014 - 1959} years old. }
p %i{ a b c }

d = "David"
p %I{"#{d}"}



puts