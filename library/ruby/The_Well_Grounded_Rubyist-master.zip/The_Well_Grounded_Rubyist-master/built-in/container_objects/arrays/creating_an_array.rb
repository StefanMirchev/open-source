puts



p a = Array.new(3)
p a = Array.new(3, "abc")

n = 0
p Array.new(3) { n += 1; n * 10 }



puts