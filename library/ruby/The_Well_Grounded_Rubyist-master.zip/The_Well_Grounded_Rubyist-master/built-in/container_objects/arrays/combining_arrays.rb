puts



puts 'concat'
a = [1,2,3]
b = [4,5,6]
p a.concat(b)

puts 'push'
a = [1,2,3]
b = [4,5,6]
p a.push(b)

puts 'replace'
a = [1,2,3]
b = [4,5,6]
p a.replace(b)



puts