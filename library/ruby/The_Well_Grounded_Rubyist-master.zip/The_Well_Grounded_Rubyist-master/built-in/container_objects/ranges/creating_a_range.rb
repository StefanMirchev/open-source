puts


# example
p r = Range.new(1,10)

# inclusive range
p r = 1..100

# exclusive
p r = 1...100

p Range.new(1,100,true)



puts