puts



require 'time'
# require 'date'

dt = DateTime.now
p dt
puts dt

p dt.year
p dt.hour
p dt.minute
p dt.second

puts

t = Time.now
p t
puts t
p t.month
p t.sec

puts

p d = Date.today
puts d = Date.today
p d.day

puts

p d.monday?
p dt.friday?



puts