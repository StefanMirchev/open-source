puts



p Time.new
p Time.at(100000000)
p Time.mktime(2007, 10, 3, 14, 3, 6)
require 'time'
p Time.parse("March 22, 1985, 10:35 PM")

puts

puts DateTime.new(2009, 1, 2, 3, 4, 5)
puts DateTime.now
puts DateTime.parse("October 23, 1973, 10:34 AM")



puts