puts



p 1 + 1
p 10/5
p 16/5
p 10/3.3
p 1.2 + 3
p -12 - -7.0
p 10 % 3

puts

p "Hexademical integers"
p 0x12
p 0x12 + 3.0

puts

p 'Integers beginning with 0 are interpreted as octal'
p 012
p 012 + 0x12
p 012 + 12




puts