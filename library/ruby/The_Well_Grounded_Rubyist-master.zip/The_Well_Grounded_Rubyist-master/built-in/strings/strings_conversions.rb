puts



p "100".to_i(17)



puts