puts



string = "Ruby is a cool language."
p string
puts
p '5'
p string[5]
puts
p '-1'
p string[-1]
puts
p '5 10'
p string[5,10]
puts
p '-12 -3'
p string[-12..-3]
puts
p '12 20'
p string[-12..20]
puts
p '15 -1'
p string[15..-1]



puts