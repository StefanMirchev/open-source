puts



p "a" <=> "b" # -1
p "b" > "a" # true
p "a" > "A" # true
p "." > "," # true
p "string" == "string" # true
p "string" == "house" # false
p "a" == "a" # true
p "a".equal?("a") # false



puts