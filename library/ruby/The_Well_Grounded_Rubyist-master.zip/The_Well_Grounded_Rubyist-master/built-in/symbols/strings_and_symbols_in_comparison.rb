puts



puts Symbol.instance_methods(false).sort



puts