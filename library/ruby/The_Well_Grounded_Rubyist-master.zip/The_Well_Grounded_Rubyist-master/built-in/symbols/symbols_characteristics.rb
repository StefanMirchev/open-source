puts



# Immutability
# Uniqueness

# will result different ids
p "abc".object_id
p "abc".object_id

puts

# will result the same ids
p :abc.object_id
p :abc.object_id




puts