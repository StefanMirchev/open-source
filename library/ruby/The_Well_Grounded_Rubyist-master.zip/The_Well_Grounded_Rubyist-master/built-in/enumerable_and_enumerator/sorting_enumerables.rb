puts



p [3,2,5,4,1].sort



puts