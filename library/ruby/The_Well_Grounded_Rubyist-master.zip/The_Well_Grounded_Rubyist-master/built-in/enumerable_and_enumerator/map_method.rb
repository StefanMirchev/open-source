puts



names = %w{ David Yukihiro Chad Amy }
names.map {|name| p name.upcase }

puts

array = [1,2,3,4,5]
result = array.map {|n| puts n * 100 }



puts