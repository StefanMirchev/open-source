puts



puts "I am a String object".methods.sort



puts