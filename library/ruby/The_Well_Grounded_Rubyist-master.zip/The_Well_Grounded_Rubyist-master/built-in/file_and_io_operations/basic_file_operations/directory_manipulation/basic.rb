puts



# Dir.mkdir('test')
Dir.mkdir 'test' unless File.exists?('test')
p d = Dir.new("test")



puts