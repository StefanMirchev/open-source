puts



# will check for syntax errors
# ruby -cw filename.rb



puts