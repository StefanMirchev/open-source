puts



# a = 10

# if a = 10
#   puts "a is equal to 10"
# elsif a < 10
#   puts "a is less than 10"
# else
#   puts "a is greater than 10"
# end


# x = 11

# if x > 10 then puts x end
# # or
# if x > 10; puts x; end


# print "Enter an integer: "
# n = gets.to_i
# if n > 0
#   puts "Your number is positive."
# elsif n < 0
#   puts "Your number is negative."
# else
#   puts "Your number is zero."
# end


x = 1

if not (x == 1)     # or if !(x == 1) or if not x == 1
  puts "Is not equal to 1"
else
  puts "Is equal to 1"
end


if some_condition
  nested_condition ? nested_something : nested_something_else
else
  something_else
end


# do_something if some_condition

# some_condition and do_something



puts