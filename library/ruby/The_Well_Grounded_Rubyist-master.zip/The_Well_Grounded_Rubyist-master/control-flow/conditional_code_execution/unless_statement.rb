puts



# x = 2

# unless x == 1
#   puts "#{x} is not equal to 1"
# end


# x = 500

# unless x > 100
#   puts "Small number!"
# else
#   puts "Big number!"
# end


x = 500

puts "Big number!" unless x <= 100



puts