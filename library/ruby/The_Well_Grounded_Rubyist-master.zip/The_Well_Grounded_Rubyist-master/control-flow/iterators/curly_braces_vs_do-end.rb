puts



array = [1, 2, 3]
puts array
array2 = array.map {|n| n * 10 }
puts array2
array2 = array.map do |n| n * 10 end
puts array2



puts