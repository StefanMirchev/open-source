puts



n = 1
loop { n += 1; puts n }



puts