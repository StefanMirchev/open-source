puts



n = 1
n = n + 1 until n == 10
puts "We've reached 10!"

# a = 1
# a += 1 until true



puts