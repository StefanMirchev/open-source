puts



n = 1
until n > 10
  puts n
  n = n + 1
end



puts