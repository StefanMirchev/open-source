puts



# set the variable to the specified value—which in
# this case is a new, a
b ||= a

a +=b ...

a **= b

if account && account.owner && account.owner.address
end
# equals
if account&.owner&.address
end
# &= (bitwise AND)

# |= bitwise OR

# ^= (bitwise EXCLUSIVE OR)

# %= модуль



puts