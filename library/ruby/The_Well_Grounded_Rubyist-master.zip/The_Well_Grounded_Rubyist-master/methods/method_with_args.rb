puts



# Defining method with args: Celsius-to-Fahrenheit converter
def obj.c2f(c)
  c * 9.0 / 5 + 32
  # optional with return
  # return c * 9.0 / 5 + 32
end

# engaging method with an arg
puts obj.c2f(32)



puts