puts



valid variables = 5
x = '3gfdgd'
_x
name
first_name
plan9
user_ID
_

x = 0
x += 1
puts x



puts