puts



require 'time'

# Ruby has a Time class. It lets you manipulate times, format them for
# timestamp purposes, and so forth.
puts Time.new.strftime("%m-%d-%y")

t = Time.new

puts t

# will result an error if require 'time' not exist(doesnt work)
t.xmlschema



puts